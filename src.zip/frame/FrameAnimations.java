package frame;

public enum FrameAnimations {
    BE_ATTACK,
    GAME_OVER
}
