package Entities.InterFaces;

import PlayerAssets.Player;

public interface Dodgeable {
    void abilityRelease(Player p, double damage);
}
