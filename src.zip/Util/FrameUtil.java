package Util;

import frame.Frame;

public class FrameUtil {
    public static final Frame MAIN_FRAME = new Frame();
    public static final Frame FIGHT_FRAME = new Frame();
    public static final Frame OTHER_FRAME = new Frame();
}
